import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rsvpcomponent',
  templateUrl: './rsvpcomponent.component.html',
  styleUrls: ['./rsvpcomponent.component.css']
})
export class RSVPComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
