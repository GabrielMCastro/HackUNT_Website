import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-devcountdown',
  templateUrl: './devcountdown.component.html',
  styleUrls: ['./devcountdown.component.css']
})
export class DevcountdownComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
