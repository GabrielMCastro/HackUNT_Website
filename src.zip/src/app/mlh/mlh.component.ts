import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mlh',
  templateUrl: './mlh.component.html',
  styleUrls: ['./mlh.component.css']
})
export class MlhComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
